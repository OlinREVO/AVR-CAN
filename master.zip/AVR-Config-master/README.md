AVR Config Files
================

Configuration files and patches to program AVRs on Linux. Includes an avrdude part definition for the ATmega16M1. 
